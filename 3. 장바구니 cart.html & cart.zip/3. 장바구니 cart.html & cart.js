<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>장바구니</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>장바구니</h2>
  <div id="cart-items"></div>
  <button onclick="checkout()">결제하기</button>

  <script src="cart.js"></script>
</body>
</html>
